package ra.edu.presentation;

public class MainUI {
    public static void main(String[] args) {
        LoginUI.displayLoginMenu();
    }
}
