package ra.edu.business.dao;

public interface AppDAO {
}
