import ra.edu.presentation.MainUI;

public class MainApplication {
    public static void main(String[] args) {
        MainUI.main(args);
    }
}
